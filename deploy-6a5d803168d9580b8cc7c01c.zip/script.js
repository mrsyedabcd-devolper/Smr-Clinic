const menuToggle = document.getElementById('menuToggle');
const navbar = document.getElementById('navbar');
const appointmentForm = document.getElementById('appointment-form');
const navLinks = document.querySelectorAll('.navbar a, .dropdown-content a');

if (menuToggle && navbar) {
    menuToggle.addEventListener('change', () => {
        if (menuToggle.checked) {
            navbar.style.display = 'flex';
        } else {
            navbar.style.display = 'none';
        }
    });

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            menuToggle.checked = false;
            if (window.innerWidth <= 768) {
                navbar.style.display = 'none';
            }
        });
    });

    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            navbar.style.display = 'flex';
            menuToggle.checked = false;
        } else if (!menuToggle.checked) {
            navbar.style.display = 'none';
        }
    });
}

if (appointmentForm) {
    appointmentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const clientName = document.getElementById('name').value.trim();
        const serviceSelect = document.getElementById('service');
        const selectedService = serviceSelect.options[serviceSelect.selectedIndex].text;
        const preferredDate = document.getElementById('date').value;

        if (!clientName || serviceSelect.value === "" || !preferredDate) {
            alert("Please fill out all the mandatory fields correctly.");
            return;
        }

        alert(`Thank you, ${clientName}!\n\nYour appointment request for "${selectedService}" on ${preferredDate} has been successfully submitted. Our medical front-desk executive will call you shortly.`);
        
        this.reset();
    });
}
